<button class="menu"><a href="mhs.php">Mahasiswa</a></button>
<button class="menu"><a href="ta.php">Tahun Ajaran</a></button>
<button class="menu"><a href="mk.php">Mata Kuliah</a></button>
<button class="menu"><a href="krs.php">KRS</a></button>
<br><br>