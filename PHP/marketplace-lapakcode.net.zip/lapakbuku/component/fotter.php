<style type="text/css">
	.wrapper-fotter{width: 100%; margin-top: 50px;}
	.wrap-fotter{ background: #eee;overflow: hidden; }
	.contain-fotter{padding:25px 15px; float:left; color:#444; font-size:14px; margin-left: 2.5%; width: 200px;}
	.contain-fotter h3{text-align: center;}
	.contain-fotter p{text-align: center;}
</style>
<div class="wrapper-fotter">
	<div class="wrap-fotter">
		<div class="contain-fotter">
			<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Costumer Suport</h3>
			<p>Pelayanan servise yang memuaskan dan Baik sedia 24 Jam</p>
		</div>
		<div class="contain-fotter">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Metode Pembayaran</h3>
			<p>Pembayaran Dengan Mudah dan terjamin Aman 100% Uang Kembali</p>
		</div>
		<div class="contain-fotter">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Patrner Pengiriman</h3>
			<p>Partner Pengiriman Yang Cekatan Yang mengantar Pesanan Anda Tepat Waktu</p>
		</div>
		<div class="contain-fotter">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Bukadompet</h3>
			<p>Bukadompet disinilah uang anda disimpan disini juga dapat menabung disini</p>
		</div>
		<div class="contain-fotter">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Akses Service</h3>
			<p>Akses Cepat di berbagai platform yang mudah dan nyaman </p>
		</div>
	</div>
	<div class="wrap-fotter" style="background: #4689db; overflow: hidden; margin-top:0px">
		<div class="contain-fotter" style="color: #fff">
			<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Costumer Suport</h3>
			<p>Pelayanan servise yang memuaskan dan Baik sedia 24 Jam</p>
		</div>
		<div class="contain-fotter" style="color: #fff">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Metode Pembayaran</h3>
			<p>Pembayaran Dengan Mudah dan terjamin Aman 100% Uang Kembali</p>
		</div>
		<div class="contain-fotter" style="color: #fff">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Patrner Pengiriman</h3>
			<p>Partner Pengiriman Yang Cekatan Yang mengantar Pesanan Anda Tepat Waktu</p>
		</div>
		<div class="contain-fotter" style="color: #fff">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Bukadompet</h3>
			<p>Bukadompet disinilah uang anda disimpan disini juga dapat menabung disini</p>
		</div>
		<div class="contain-fotter" style="color: #fff">
		<center><img src="../asset/image/icon/large-icon-user.png" style="width: 50px; height: 50px; "></center>
			<h3>Akses Service</h3>
			<p>Akses Cepat di berbagai platform yang mudah dan nyaman </p>
		</div>
	</div>
</div>
<span style="background: #469; padding: 20px 15px; color: #fff; font-size: 13px; display: inherit; margin-top: 0">Copyright 2017 | CEO Lapakcode.net</span>
	