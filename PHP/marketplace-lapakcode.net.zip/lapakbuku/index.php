<!DOCTYPE html>
<html>
<head>
	<title>Situs Jual Beli Buku Terpercaya</title>
	<link rel="stylesheet" type="text/css" href="asset/css/jquery-ui.min.css">
	<link rel="stylesheet" type="text/css" href="asset/css/style.css">
	<link rel="stylesheet" type="text/css" href="asset/css/slider.css">
	  <script type="text/javascript" src="asset/js/jquery.min.js"></script>
       <script type="text/javascript" src="asset/js/jquery-ui.min.js"></script>
</head>
<body>
<div>
<?php include 'component/header.php'; ?>
<?php include 'component/slider.php'; ?>
<?php include 'component/search-panel.php'; ?>
<?php include 'component/new_book.php'; ?>
<?php include 'component/new-product.php'; ?>
<?php include 'component/favorit_book.php'; ?>	
</div>
<div style="clear: both;"></div>
<?php include 'component/fotter.php'; ?>
</body>
</html>