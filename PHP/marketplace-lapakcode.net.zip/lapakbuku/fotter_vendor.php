  <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2017| By : <a href="http://www.lapakcode.net/" target="_blank">lapakcode.net</a>
                </div>

            </div>
        </div>
    </footer>